import { Predicate } from '@angular/core';
import * as signalR from '@aspnet/signalr';
import { RoomViewModel } from './room-view-model';
import { Message } from './message';

export class Signalr {
private hubConnection;

constructor(uri: string)
{
    this.hubConnection = new signalR.HubConnectionBuilder().withUrl(uri).build();
}

registerRoom(methodname: string, method: Predicate<RoomViewModel>){
this.hubConnection.on(methodname, method);
}

registerMessage(methodname: string, method: Predicate<Message>){
    this.hubConnection.on(methodname, method);
    }

start() {
    this.hubConnection.start().then(() => {}).catch();
}
}
