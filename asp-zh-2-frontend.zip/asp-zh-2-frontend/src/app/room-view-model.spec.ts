import { RoomViewModel } from './room-view-model';

describe('RoomViewModel', () => {
  it('should create an instance', () => {
    expect(new RoomViewModel()).toBeTruthy();
  });
});
