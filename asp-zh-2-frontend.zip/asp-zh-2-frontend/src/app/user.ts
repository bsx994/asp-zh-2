export class User {
    public email = "";
    public password = "";


}
