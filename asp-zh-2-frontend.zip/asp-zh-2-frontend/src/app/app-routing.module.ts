import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ChatRoomComponentComponent } from './chat-room-component/chat-room-component.component';
import { LoginComponentComponent } from './login-component/login-component.component';

const routes: Routes = [
  {path: 'messageRoom', component: ChatRoomComponentComponent},
  {path: 'login', component: LoginComponentComponent}
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
