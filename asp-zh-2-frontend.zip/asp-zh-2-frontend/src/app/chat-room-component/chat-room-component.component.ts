import { HttpClient } from '@angular/common/http';
import { Message } from '../message';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RoomViewModel } from '../room-view-model';
import { Signalr } from '../signalr';

@Component({
  selector: 'app-chat-room-component',
  templateUrl: './chat-room-component.component.html',
  styleUrls: ['./chat-room-component.component.css']
})
export class ChatRoomComponentComponent implements OnInit {

private router: Router;
private token: string;
public lobbies: Array<RoomViewModel>;
public messages: Array<Message>;
private http: HttpClient;
// private sr;

  constructor(router: Router, http: HttpClient) { 
    this.router = router;
    this.http = http;
    this.lobbies = new Array<RoomViewModel>();
    this.messages = new Array<Message>();
    const _token = sessionStorage.getItem('token');
    
    this.token = _token !== null ? _token : "";
    if (this.token == null || this.token.toString().length < 3)
    {
      this.router.navigate(['/login']);
    } else
    {
      const headers ={
        'Content-type': 'application/json',
        Authorization: 'Bearer ' + this.token
      };

      this.http.get<RoomViewModel[]>('https://localhost:44325/api/room').subscribe(response =>
      {
        this.lobbies = response;
      });
/* 
      this.sr = new Signalr('https://localhost:44325/chathub');
      this.sr.registerRoom('addRoom', l => {
        this.lobbies.push(l);
        return true;
      });
      this.sr.registerMessage('sendMessage', m => {
        this.messages.push(m);
        return true;
      });
      this.sr.start(); */
    }

  }
  
  onClickRoom(room: RoomViewModel)
  {
    this.http.get<Message[]>('https://localhost:44325/api/message/'+room.uid).subscribe(response =>
      {
        this.messages = response;
      });
  }

  addRoom(name: string){
    this.http.post('https://localhost:44325/api/room', name);
  }

  sendMessage(message: Message)
  {
    this.http.post('https://localhost:44325/api/message', message);
  }

  ngOnInit(): void {
  }

}
