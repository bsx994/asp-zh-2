export class LoginResponse {
    public token = "";
    public expiration = "";
}
