export class RoomViewModel {
    public uid ="";
    public roomname = "";
    public messagecount = 0;
}
