export class Message {
    public user = "";
    public text = "";
    public roomUid = "";

}
