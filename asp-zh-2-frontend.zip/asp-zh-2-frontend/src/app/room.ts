import { Message } from '@angular/compiler/src/i18n/i18n_ast';

export class Room {
    public uid = "";
    public roomname ="";
    public messages = new Array<Message>();
    public creator = "";
}
