import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { HttpClient } from '@angular/common/http';
import { LoginResponse } from '../login-response';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})
export class LoginComponentComponent implements OnInit {

  private http: HttpClient;
  private router: Router;

  constructor(http: HttpClient, router: Router) {
    this.http = http;
    this.router = router;
   }

  login(email: HTMLInputElement, pass: HTMLInputElement) {
    const actualuser = new User();
    actualuser.email = email.value;
    actualuser.password = pass.value;
    alert(actualuser.email+" "+ actualuser.password);
    this.http.post<LoginResponse>('https://localhost:44325/login', actualuser).subscribe(response => {
      const token = response.token;
      if (token.toString().length > 3 && token != null){
        sessionStorage.setItem('token', token);
        sessionStorage.setItem('user', actualuser.email);
        this.router.navigate(['/messageRoom']);
      }
    }, error => {
      if (error.status.toString() === '401')
      {
        window.alert('Invalid username or password')
      }
      else
      {
        window.alert('server down')
      }
    });
  }

  ngOnInit(): void {
  }

}
